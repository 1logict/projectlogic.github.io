const prompts = {
  website: [
    {
      ai: "ChatGPT",
      summary: "Build website layout & components",
      prompt: "Create a complete website structure with navbar, hero section, features, footer, including design tips."
    },
    {
      ai: "Gemini",
      summary: "Design dark theme UI/UX",
      prompt: "Generate UI/UX design ideas for a responsive website in dark theme. Include fonts and layout."
    },
    {
      ai: "Claude",
      summary: "Recommend JS libraries",
      prompt: "List advanced JavaScript libraries/frameworks with sample integration code."
    }
  ],
  research: [
    {
      ai: "ChatGPT",
      summary: "Create research paper outline",
      prompt: "Generate a research paper outline on AI in Healthcare. Include abstract, intro, methodology, results."
    },
    {
      ai: "Gemini",
      summary: "Suggest trending AI topics",
      prompt: "Suggest trending research areas in AI for publication in top journals."
    },
    {
      ai: "Claude",
      summary: "Explain IEEE/ACM submission",
      prompt: "Guide on publishing a paper in IEEE or ACM. Include formatting and review process."
    }
  ],
  presentation: [
    {
      ai: "ChatGPT",
      summary: "Make AI ppt slides",
      prompt: "Create presentation slides on Generative AI covering history, applications, risks, and future scope."
    },
    {
      ai: "Gemini",
      summary: "Design slide layout",
      prompt: "Design a clean layout and slide format for a tech presentation using Google Slides."
    }
  ],
  business: [
    {
      ai: "ChatGPT",
      summary: "Startup pitch deck",
      prompt: "Generate a startup pitch deck outline for an AI-based EdTech product."
    },
    {
      ai: "Gemini",
      summary: "Marketing strategy",
      prompt: "Create a social media marketing plan for an online tea-selling business."
    }
  ]
};

const taskDropdown = document.getElementById("task");
const promptContainer = document.getElementById("promptCards");
const searchBar = document.getElementById("searchBar");
const favoriteList = document.getElementById("favoriteList");
const themeToggle = document.getElementById("themeToggle");
const downloadFavorites = document.getElementById("downloadFavorites");

let favorites = [];

function populateDropdown() {
  Object.keys(prompts).forEach((task) => {
    const option = document.createElement("option");
    option.value = task;
    option.textContent = task.charAt(0).toUpperCase() + task.slice(1);
    taskDropdown.appendChild(option);
  });
}

function renderPrompts(taskType) {
  promptContainer.innerHTML = "";
  prompts[taskType].forEach((item) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h2>AI Engine: ${item.ai}</h2>
      <h4>🧠 Task: ${item.summary}</h4>
      <p>${item.prompt}</p>
      <button class="copy-button">Copy Prompt</button>
      <button class="favorite-button">Add to Favorites</button>
    `;
    card.querySelector(".copy-button").addEventListener("click", () => {
      navigator.clipboard.writeText(item.prompt);
      alert("Prompt copied to clipboard!");
    });
    card.querySelector(".favorite-button").addEventListener("click", () => {
      favorites.push(item);
      renderFavorites();
    });
    promptContainer.appendChild(card);
  });
}

function renderFavorites() {
  favoriteList.innerHTML = "";
  favorites.forEach((fav, index) => {
    const favItem = document.createElement("div");
    favItem.className = "card";
    favItem.innerHTML = `
      <h3>${fav.ai}</h3>
      <h4>${fav.summary}</h4>
      <p>${fav.prompt}</p>
    `;
    favoriteList.appendChild(favItem);
  });
}

searchBar.addEventListener("input", () => {
  const keyword = searchBar.value.toLowerCase();
  const taskType = taskDropdown.value;
  const filtered = prompts[taskType].filter((item) =>
    item.prompt.toLowerCase().includes(keyword) || item.summary.toLowerCase().includes(keyword)
  );
  promptContainer.innerHTML = "";
  filtered.forEach((item) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h2>AI Engine: ${item.ai}</h2>
      <h4>🧠 Task: ${item.summary}</h4>
      <p>${item.prompt}</p>
      <button class="copy-button">Copy Prompt</button>
      <button class="favorite-button">Add to Favorites</button>
    `;
    card.querySelector(".copy-button").addEventListener("click", () => {
      navigator.clipboard.writeText(item.prompt);
      alert("Prompt copied to clipboard!");
    });
    card.querySelector(".favorite-button").addEventListener("click", () => {
      favorites.push(item);
      renderFavorites();
    });
    promptContainer.appendChild(card);
  });
});

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light");
});

downloadFavorites.addEventListener("click", () => {
  const blob = new Blob([
    favorites.map(f => `AI: ${f.ai}
Task: ${f.summary}
Prompt: ${f.prompt}
---`).join("

")
  ], { type: 'text/plain' });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "favorite-prompts.txt";
  link.click();
});

populateDropdown();
renderPrompts(taskDropdown.value);

taskDropdown.addEventListener("change", (e) => {
  renderPrompts(e.target.value);
});